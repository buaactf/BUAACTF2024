#!/bin/sh
mv /app/images/* /tmp/
rm -rf /app/images
node app.js